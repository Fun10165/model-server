"""
Author: zbmaincn@gmail.com
Description: Ark Chat wrapper.
"""

from langchain_ark.chat_models import ChatArk

__all__ = ["ChatArk"]
