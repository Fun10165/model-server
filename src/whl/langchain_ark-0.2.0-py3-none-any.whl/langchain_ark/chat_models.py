# chat_models.py (for langchain-ark)

from __future__ import annotations

import json
from json import JSONDecodeError
from typing import Any, Literal, Optional, TypeVar, Union

import openai
from langchain_core.callbacks import (
    CallbackManagerForLLMRun,
)
from langchain_core.language_models import LanguageModelInput
from langchain_core.messages import BaseMessage
from langchain_core.outputs import ChatResult
from langchain_core.runnables import Runnable
from langchain_core.utils import from_env, secret_from_env
from langchain_openai.chat_models.base import BaseChatOpenAI
from pydantic import BaseModel, ConfigDict, Field, SecretStr, model_validator
from typing_extensions import Self

# 查阅火山方舟文档，其兼容OpenAI的API endpoint基准URL
# 通常为 https://ark.cn-beijing.volces.com/api/v3
DEFAULT_API_BASE = "https://ark.cn-beijing.volces.com/api/v3"

_BM = TypeVar("_BM", bound=BaseModel)
_DictOrPydanticClass = Union[dict[str, Any], type[_BM], type]
_DictOrPydantic = Union[dict, _BM]


class ChatArk(BaseChatOpenAI):
    """火山方舟(VolcanoEngine ARK)聊天模型接口.

    设置:
        安装 `langchain-ark` 和 `langchain-openai`，并设置环境变量 `ARK_API_KEY`。

        .. code-block:: bash

            pip install -U langchain-ark langchain-openai
            export ARK_API_KEY="your-api-key"

    主要初始化参数 — 模型参数:
        model: str
            要使用的方舟模型名称, 例如 "ep-20240618171112-42175".
        temperature: float
            采样温度。
        max_tokens: Optional[int]
            要生成的最大token数。

    主要初始化参数 — 客户端参数:
        timeout: Optional[float]
            请求超时时间。
        max_retries: int
            最大重试次数。
        api_key: Optional[str]
            方舟 API 密钥。如果未传入，将从环境变量 ARK_API_KEY 读取。
        base_url: Optional[str]
            方舟 API 的基准URL。如果未传入，将从环境变量 ARK_API_BASE 读取，默认为
            "https://ark.cn-beijing.volces.com/api/v3"。

    查看 `langchain_openai.ChatOpenAI` 以获取所有支持的初始化参数。

    实例化:
        .. code-block:: python

            from langchain_ark import ChatArk

            llm = ChatArk(
                model="ep-20240618171112-42175",
                temperature=0,
                max_tokens=None,
                max_retries=2,
                # api_key="...",
                # base_url="...",
                # 其他参数...
            )

    调用 (Invoke):
        .. code-block:: python

            messages = [
                ("system", "你是一个乐于助人的助手。"),
                ("human", "长城有多长?"),
            ]
            llm.invoke(messages)

    流式 (Stream):
        .. code-block:: python

            for chunk in llm.stream(messages):
                print(chunk.content, end="", flush=True)

    工具调用 (Tool calling):
        .. code-block:: python

            from pydantic import BaseModel, Field

            class GetWeather(BaseModel):
                '''获取给定地点的当前天气'''
                location: str = Field(..., description="城市和省份, e.g. 北京市")

            llm_with_tools = llm.bind_tools([GetWeather])
            ai_msg = llm_with_tools.invoke("今天上海的天气怎么样?")
            ai_msg.tool_calls

    结构化输出 (Structured output):
        .. code-block:: python

            from typing import Optional
            from pydantic import BaseModel, Field

            class Joke(BaseModel):
                '''用来讲给用户的笑话。'''
                setup: str = Field(description="笑话的铺垫")
                punchline: str = Field(description="笑话的笑点")
                rating: Optional[int] = Field(description="笑话有多好笑，从1到10")

            structured_llm = llm.with_structured_output(Joke)
            structured_llm.invoke("给我讲个关于程序员的笑话")
    """

    model_name: str = Field(alias="model")
    """要使用的模型端点名称"""
    api_key: Optional[SecretStr] = Field(
        default_factory=secret_from_env("ARK_API_KEY", default=None),
        alias="ark_api_key", # 兼容旧版命名
    )
    """方舟 API 密钥"""
    api_base: str = Field(
        default_factory=from_env("ARK_API_BASE", default=DEFAULT_API_BASE),
        alias="ark_api_base", # 兼容旧版命名
    )
    """方舟 API 基准 URL"""

    # 重写 model_config 以接受别名
    model_config = ConfigDict(populate_by_name=True)

    @property
    def _llm_type(self) -> str:
        """返回聊天模型的类型。"""
        return "chat-ark"

    @property
    def lc_secrets(self) -> dict[str, str]:
        """一个从构造函数参数名到密钥ID的映射。"""
        return {"api_key": "ARK_API_KEY"}

    @model_validator(mode="after")
    def validate_environment(self) -> Self:
        """验证环境配置并初始化客户端。"""
        # 为了向后兼容，允许使用旧的属性名进行初始化
        if self.model_config.get("ark_api_key"):
            self.api_key = self.model_config.get("ark_api_key")
        if self.model_config.get("ark_api_base"):
            self.api_base = self.model_config.get("ark_api_base")

        if not (self.api_key and self.api_key.get_secret_value()):
            raise ValueError("必须设置 ARK_API_KEY 环境变量或在初始化时传入 `api_key`。")

        # 使用继承自 BaseChatOpenAI 的逻辑来设置 openai 客户端
        # 但将 api_key 和 base_url 指向 ARK 的配置
        client_params: dict = {
            k: v
            for k, v in {
                "api_key": self.api_key.get_secret_value() if self.api_key else None,
                "base_url": self.api_base,
                "timeout": self.request_timeout,
                "max_retries": self.max_retries,
                "default_headers": self.default_headers,
                "default_query": self.default_query,
            }.items()
            if v is not None
        }

        if not self.client:
            sync_specific: dict = {"http_client": self.http_client}
            # 使用 openai.OpenAI 客户端，但配置为连接到 ARK 的端点
            self.root_client = openai.OpenAI(**client_params, **sync_specific)
            self.client = self.root_client.chat.completions
        if not self.async_client:
            async_specific: dict = {"http_client": self.http_async_client}
            # 使用 openai.AsyncOpenAI 客户端，但配置为连接到 ARK 的端点
            self.root_async_client = openai.AsyncOpenAI(
                **client_params,
                **async_specific,
            )
            self.async_client = self.root_async_client.chat.completions
        return self

    def _generate(
        self,
        messages: list[BaseMessage],
        stop: Optional[list[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        """
        重写 _generate 以捕获 ARK 可能返回的特定错误。
        此处我们先假设其行为与OpenAI完全一致，但添加错误处理层。
        """
        try:
            # 直接调用父类的 _generate 方法，它包含了缓存、流式处理切换等复杂逻辑
            return super()._generate(
                messages,
                stop=stop,
                run_manager=run_manager,
                **kwargs,
            )
        except JSONDecodeError as e:
            msg = (
                "ARK API 返回了无效的 JSON 响应。请检查 API 状态并重试。"
                "确认您的 base_url 配置是否正确。"
            )
            raise JSONDecodeError(
                msg,
                e.doc,
                e.pos,
            ) from e
        except openai.BadRequestError as e:
            # 捕获并重新包装特定的 openai 客户端错误
            # 这里的错误信息可能需要根据 ARK 的实际返回进行调整
            raise ValueError(f"从 ARK API 收到错误请求: {e}") from e

    # 注意：with_structured_output 等高级功能现在由父类 BaseChatOpenAI 提供
    # 我们不需要在这里重写它们，除非 ARK 的实现有特殊之处。
    # 例如，DeepSeek 重写了 with_structured_output 以添加 "json_schema" 方法，
    # 这里我们暂时不添加，以保持与标准 OpenAI API 的最大兼容性。